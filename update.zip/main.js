const { app, BrowserWindow, ipcMain, shell, dialog, globalShortcut, Tray, Menu, nativeImage } = require('electron');
const { exec, spawn } = require('child_process');
const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');

const run = (cmd) =>
  new Promise((res) =>
    exec(cmd, { windowsHide: true, maxBuffer: 1e7 }, (e, out) => res({ ok: !e, out: (out || '').trim() }))
  );
const ps = (s) =>
  run('powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand ' + Buffer.from(s, 'utf16le').toString('base64'));
const q = (s) => String(s).replace(/'/g, "''");
const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');

let win;
let machine = '';
let adminSession = false;
let fails = 0;
let lockUntil = 0;

// ================= Réglages (téléchargements) =================
const defaults = { dlEnabled: false, dlMinutes: 60, dlPermanent: false, hotkey: '', hideTray: false, applied: [], customApps: [], live: [], liveOn: false, boosted: [], aiKey: '' };
let settings = { ...defaults };
const sFile = () => path.join(app.getPath('userData'), 'settings.json');
const save = () => fs.writeFileSync(sFile(), JSON.stringify(settings));

// ================= Licences (codes signés Ed25519) =================
// Le mot de passe admin ne sert qu'à ouvrir l'écran. La vraie protection : la clé privée (admin.key) reste sur TON PC.
const PWH = sha('201212');
const SALT = 'nb2-9f3a71c4';
const UNITS = { minute: 60, heure: 3600, jour: 86400, semaine: 604800, mois: 2592000, an: 31536000 };
const pubFile = () => path.join(app.getAppPath(), 'license-public.pem');
const privFile = () => path.join(app.getPath('userData'), 'admin.key');
const licFile = () => path.join(app.getPath('userData'), 'license.json');
const histFile = () => path.join(app.getPath('userData'), 'keys.json');
const cfgFile = () => path.join(app.getAppPath(), 'config.json');
const readCfg = () => {
  try {
    return JSON.parse(fs.readFileSync(cfgFile(), 'utf8'));
  } catch {
    return {};
  }
};
const owner = () => adminSession && fs.existsSync(privFile());
const sign = (data) => crypto.sign(null, Buffer.from(data), fs.readFileSync(privFile())).toString('base64');
const verifySig = (data, sig) => {
  try {
    return crypto.verify(null, Buffer.from(data), fs.readFileSync(pubFile()), Buffer.from(sig, 'base64'));
  } catch {
    return false;
  }
};
const hmac = (L) =>
  crypto.createHmac('sha256', machine + SALT).update(`${L.id}|${L.activatedAt}|${L.lastSeen}|${L.d}`).digest('hex');

async function initMachine() {
  const u = (await ps('(Get-CimInstance Win32_ComputerSystemProduct).UUID')).out || os.hostname();
  machine = sha(u).slice(0, 12).toUpperCase().match(/.{4}/g).join('-');
}

function parseKey(key) {
  try {
    const [p, s] = String(key).replace(/\s+/g, '').replace(/^NB-/, '').split('.');
    const data = Buffer.from(p, 'base64url');
    if (!crypto.verify(null, data, fs.readFileSync(pubFile()), Buffer.from(s, 'base64url'))) return null;
    return JSON.parse(data.toString());
  } catch {
    return null;
  }
}

function status() {
  if (owner()) return { ok: true, admin: true };
  let L;
  try {
    L = JSON.parse(fs.readFileSync(licFile(), 'utf8'));
  } catch {
    return { ok: false, reason: 'none' };
  }
  if (hmac(L) !== L.h) return { ok: false, reason: 'tamper' };
  const now = Date.now();
  if (now < L.lastSeen - 120000) return { ok: false, reason: 'clock' };
  const exp = L.activatedAt + L.d * 1000;
  if (now >= exp) return { ok: false, reason: 'expired' };
  if (now - L.lastSeen > 30000) {
    L.lastSeen = now;
    L.h = hmac(L);
    try {
      fs.writeFileSync(licFile(), JSON.stringify(L));
    } catch {}
  }
  return { ok: true, exp, name: L.n, since: L.activatedAt, total: L.d };
}

const guard = (fn) => async (e, ...a) => (status().ok ? fn(e, ...a) : { locked: true });

ipcMain.handle('lic:status', () => ({ ...status(), pc: machine }));

ipcMain.handle('lic:activate', async (_, key) => {
  const P = parseKey(key);
  if (!P || !/^[0-9a-f]{8,32}$/.test(P.id || '')) return { ok: false, msg: 'Code invalide.' };
  if (P.m && P.m !== machine) return { ok: false, msg: 'Ce code est lié à un autre PC.' };
  const used = await run(`reg query "HKCU\\Software\\NovaBoost" /v u_${P.id}`);
  if (used.ok) return { ok: false, msg: 'Ce code a déjà été utilisé.' };
  const now = Date.now();
  const L = { id: P.id, n: P.n, d: P.d, activatedAt: now, lastSeen: now };
  L.h = hmac(L);
  fs.writeFileSync(licFile(), JSON.stringify(L));
  await run(`reg add "HKCU\\Software\\NovaBoost" /v u_${P.id} /t REG_SZ /d ${now} /f`);
  return { ...status(), pc: machine };
});

// ================= Espace admin =================
ipcMain.handle('adm:login', (_, pw) => {
  if (Date.now() < lockUntil) return { ok: false, msg: 'Trop d’essais. Réessaie dans quelques secondes.' };
  adminSession = sha(String(pw).replace(/\D/g, '')) === PWH;
  if (adminSession) fails = 0;
  else if (++fails >= 5) {
    fails = 0;
    lockUntil = Date.now() + 30000;
  }
  return { ok: adminSession, key: fs.existsSync(privFile()), pub: fs.existsSync(pubFile()) };
});

ipcMain.handle('adm:setup', () => {
  if (!adminSession) return { ok: false };
  const hasPriv = fs.existsSync(privFile());
  const hasPub = fs.existsSync(pubFile());
  try {
    if (hasPriv && !hasPub) {
      fs.writeFileSync(pubFile(), crypto.createPublicKey(fs.readFileSync(privFile())).export({ type: 'spki', format: 'pem' }));
    } else if (!hasPriv && !hasPub) {
      const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
      fs.writeFileSync(privFile(), privateKey.export({ type: 'pkcs8', format: 'pem' }));
      fs.writeFileSync(pubFile(), publicKey.export({ type: 'spki', format: 'pem' }));
    } else if (!hasPriv) return { ok: false };
  } catch {
    return { ok: false };
  }
  return { ok: true, key: true, pub: true };
});

ipcMain.handle('adm:folder', () => owner() && shell.showItemInFolder(privFile()));

ipcMain.handle('adm:gen', (_, o) => {
  if (!owner()) return { error: 'Réservé à l’administrateur.' };
  const secs = Math.round(Number(o.n) * (UNITS[o.u] || 0));
  if (!(secs >= 60) || secs > UNITS.an * 50) return { error: 'Durée invalide (minimum 1 minute).' };
  const P = {
    id: crypto.randomBytes(6).toString('hex'),
    n: String(o.name || '').slice(0, 40),
    r: String(o.reason || '').slice(0, 80),
    d: secs,
    c: Date.now(),
    m: String(o.pc || '').trim().toUpperCase().slice(0, 14),
  };
  const data = Buffer.from(JSON.stringify(P));
  const sig = crypto.sign(null, data, fs.readFileSync(privFile()));
  let h = [];
  try {
    h = JSON.parse(fs.readFileSync(histFile(), 'utf8'));
  } catch {}
  h.unshift({ id: P.id, n: P.n, r: P.r, d: P.d, c: P.c, m: P.m });
  fs.writeFileSync(histFile(), JSON.stringify(h.slice(0, 100)));
  return { key: 'NB-' + data.toString('base64url') + '.' + sig.toString('base64url') };
});

ipcMain.handle('adm:hist', () => {
  if (!owner()) return [];
  try {
    return JSON.parse(fs.readFileSync(histFile(), 'utf8')).slice(0, 40);
  } catch {
    return [];
  }
});

ipcMain.handle('adm:url', (_, url) => {
  if (!owner()) return '';
  if (typeof url === 'string') {
    let u = url.trim();
    if (u && !u.endsWith('/')) u += '/';
    if (u && !/^https:\/\//.test(u)) return readCfg().updateUrl || '';
    fs.writeFileSync(cfgFile(), JSON.stringify({ ...readCfg(), updateUrl: u }, null, 2));
  }
  return readCfg().updateUrl || '';
});

ipcMain.handle('adm:pick', async () => {
  const r = await dialog.showOpenDialog(win, { properties: ['openDirectory'] });
  return r.canceled ? null : r.filePaths[0];
});

ipcMain.handle('adm:publish', async (_, folder, notes) => {
  if (!owner()) return { msg: 'Réservé à l’administrateur.' };
  const base = readCfg().updateUrl;
  if (!base) return { msg: 'Enregistre d’abord l’adresse en ligne.' };
  try {
    const pj = JSON.parse(fs.readFileSync(path.join(folder, 'package.json'), 'utf8'));
    if (!fs.existsSync(path.join(folder, 'main.js')) || !pj.version) throw new Error('x');
    const out = path.join(app.getPath('documents'), 'NovaBoost-publication');
    fs.mkdirSync(out, { recursive: true });
    const zip = path.join(out, 'update.zip');
    fs.rmSync(zip, { force: true });
    if (!(await ps(`Compress-Archive -Path '${q(folder)}\\*' -DestinationPath '${q(zip)}' -Force`)).ok) throw new Error('x');
    const hash = crypto.createHash('sha256').update(fs.readFileSync(zip)).digest('hex');
    const latest = {
      version: pj.version,
      notes: String(notes || '').slice(0, 300),
      sha256: hash,
      sig: sign(`${pj.version}|${hash}`),
      url: base + 'update.zip',
    };
    fs.writeFileSync(path.join(out, 'latest.json'), JSON.stringify(latest, null, 2));
    shell.openPath(out);
    return { msg: `Version ${pj.version} prête. Envoie update.zip et latest.json à l’adresse en ligne.` };
  } catch {
    return { msg: 'Dossier invalide : il doit contenir main.js et package.json (dossier resources\\app).' };
  }
});

// ================= Mises à jour =================
const cmp = (a, b) => {
  const x = String(a).split('.').map(Number);
  const y = String(b).split('.').map(Number);
  for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0);
  return 0;
};
let pending = null;

ipcMain.handle('sys:version', () => app.getVersion());

ipcMain.handle('upd:check', async () => {
  const base = readCfg().updateUrl;
  if (!base) return { none: true };
  try {
    const r = await fetch(base + 'latest.json?t=' + Date.now(), { signal: AbortSignal.timeout(10000) });
    const j = await r.json();
    if (!verifySig(`${j.version}|${j.sha256}`, j.sig) || !/^https:\/\//.test(j.url)) return { error: 'Mise à jour non signée.' };
    pending = j;
    return { latest: j.version, notes: j.notes, newer: cmp(j.version, app.getVersion()) > 0 };
  } catch {
    return { error: 'Serveur de mises à jour injoignable.' };
  }
});

ipcMain.handle('upd:install', async () => {
  if (!pending) return { ok: false, msg: 'Aucune mise à jour.' };
  try {
    const tmp = path.join(os.tmpdir(), 'nb-update');
    fs.rmSync(tmp, { recursive: true, force: true });
    fs.mkdirSync(tmp, { recursive: true });
    const buf = Buffer.from(await (await fetch(pending.url)).arrayBuffer());
    if (sha256(buf) !== pending.sha256) return { ok: false, msg: 'Fichier corrompu, mise à jour annulée.' };
    const zip = path.join(tmp, 'u.zip');
    const dir = path.join(tmp, 'x');
    fs.writeFileSync(zip, buf);
    if (!(await ps(`Expand-Archive -LiteralPath '${q(zip)}' -DestinationPath '${q(dir)}' -Force`)).ok)
      return { ok: false, msg: 'Décompression impossible.' };
    const script = `Start-Sleep 3; Copy-Item -Path '${q(dir)}\\*' -Destination '${q(app.getAppPath())}' -Recurse -Force; Start-Process '${q(process.execPath)}'`;
    spawn('powershell', ['-NoProfile', '-WindowStyle', 'Hidden', '-EncodedCommand', Buffer.from(script, 'utf16le').toString('base64')], {
      detached: true,
      stdio: 'ignore',
    }).unref();
    setTimeout(() => app.quit(), 300);
    return { ok: true };
  } catch {
    return { ok: false, msg: 'Téléchargement impossible.' };
  }
});
const sha256 = (b) => crypto.createHash('sha256').update(b).digest('hex');

// ================= Réglages Windows (réversibles) =================
const R = (k, v, d) => `reg add "${k}" /v "${v}" /t REG_DWORD /d ${d} /f`;
const RS = (k, v, d) => `reg add "${k}" /v "${v}" /t REG_SZ /d ${d} /f`;
const RD = (k, v) => `reg delete "${k}" /v "${v}" /f`;
const SUBP = '54533251-82be-4824-96c1-47b60b740d00';
const PC = (set, val) => `powercfg -setacvalueindex SCHEME_CURRENT ${SUBP} ${set} ${val}`;
const ACT = 'powercfg -setactive SCHEME_CURRENT';
const GCS = 'HKCU\\System\\GameConfigStore';
const GDVR = 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\GameDVR';
const GBAR = 'HKCU\\Software\\Microsoft\\GameBar';
const PERS = 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize';
const CDM = 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager';
const BGA = 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\BackgroundAccessApplications';
const MOU = 'HKCU\\Control Panel\\Mouse';
const MM = 'HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile';
const EXP = 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer';
const DESK = 'HKCU\\Control Panel\\Desktop';
const ACCS = 'HKCU\\Control Panel\\Accessibility';
const CDM_KEYS = [
  'SubscribedContent-338388Enabled',
  'SubscribedContent-338389Enabled',
  'SubscribedContent-310093Enabled',
  'SystemPaneSuggestionsEnabled',
  'SilentInstalledAppsEnabled',
];

// rec = inclus dans « Boost FPS » et « Optimisation en un clic »
const TWEAKS = [
  // ---- Performance ----
  { id: 'power', cat: 'Performance', rec: true, label: 'Plan d’alimentation « Performances élevées »',
    desc: 'Empêche Windows de brider le processeur pour économiser l’énergie.',
    do: ['powercfg /setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c'], undo: ['powercfg /setactive 381b4222-f694-41f0-9685-ff5bb260df2e'] },
  { id: 'unpark', cat: 'Performance', label: 'Garder tous les cœurs du processeur actifs',
    desc: 'Désactive le « core parking » (comme ParkControl) : les cœurs ne sont plus endormis.',
    do: [PC('0cc5b647-c1df-4637-891a-dec35c318583', 100), ACT], undo: [PC('0cc5b647-c1df-4637-891a-dec35c318583', 0), ACT] },
  { id: 'cpumax', cat: 'Performance', label: 'Processeur à pleine vitesse en permanence',
    desc: 'Fréquence minimale à 100 %. Plus de réactivité, mais plus de chaleur et de consommation : déconseillé sur batterie.',
    do: [PC('893dee8e-2bef-41e0-89c6-b55d0929964c', 100), ACT], undo: [PC('893dee8e-2bef-41e0-89c6-b55d0929964c', 5), ACT] },
  { id: 'prio', cat: 'Performance', admin: true, label: 'Priorité aux applications au premier plan',
    desc: 'Donne plus de temps processeur au jeu ou à l’application que tu utilises.',
    do: [R('HKLM\\SYSTEM\\CurrentControlSet\\Control\\PriorityControl', 'Win32PrioritySeparation', 38)],
    undo: [R('HKLM\\SYSTEM\\CurrentControlSet\\Control\\PriorityControl', 'Win32PrioritySeparation', 2)] },
  { id: 'mmcss', cat: 'Performance', admin: true, label: 'Priorité multimédia pour les jeux',
    desc: 'Règle le planificateur de Windows (MMCSS) pour favoriser les jeux.',
    do: [R(MM, 'SystemResponsiveness', 10), R(MM + '\\Tasks\\Games', 'GPU Priority', 8), R(MM + '\\Tasks\\Games', 'Priority', 6),
      RS(MM + '\\Tasks\\Games', 'Scheduling Category', 'High'), RS(MM + '\\Tasks\\Games', 'SFIO Priority', 'High')],
    undo: [R(MM, 'SystemResponsiveness', 20), R(MM + '\\Tasks\\Games', 'Priority', 2),
      RS(MM + '\\Tasks\\Games', 'Scheduling Category', 'Medium'), RS(MM + '\\Tasks\\Games', 'SFIO Priority', 'Normal')] },
  { id: 'hags', cat: 'Performance', admin: true, reboot: true, label: 'Planification GPU accélérée par le matériel',
    desc: 'Peut améliorer la fluidité selon ta carte graphique. À tester : l’effet varie.',
    do: [R('HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers', 'HwSchMode', 2)],
    undo: [R('HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers', 'HwSchMode', 1)] },
  // ---- Jeux ----
  { id: 'gm', cat: 'Jeux', rec: true, label: 'Activer le Mode Jeu de Windows',
    desc: 'Windows limite les tâches en arrière-plan pendant que tu joues.',
    do: [R(GBAR, 'AutoGameModeEnabled', 1), R(GBAR, 'AllowAutoGameMode', 1)], undo: [] },
  { id: 'dvr', cat: 'Jeux', rec: true, label: 'Couper l’enregistrement vidéo en arrière-plan (Game DVR)',
    desc: 'Évite que Windows enregistre ton écran en permanence.',
    do: [R(GCS, 'GameDVR_Enabled', 0), R(GDVR, 'AppCaptureEnabled', 0)], undo: [R(GCS, 'GameDVR_Enabled', 1), R(GDVR, 'AppCaptureEnabled', 1)] },
  { id: 'gamebar', cat: 'Jeux', rec: true, label: 'Couper la Game Bar',
    desc: 'Supprime les fenêtres Xbox qui s’ouvrent pendant les parties.',
    do: [R(GBAR, 'UseNexusForGameBarEnabled', 0), R(GBAR, 'ShowStartupPanel', 0)], undo: [R(GBAR, 'UseNexusForGameBarEnabled', 1), R(GBAR, 'ShowStartupPanel', 1)] },
  { id: 'fso', cat: 'Jeux', label: 'Désactiver les optimisations plein écran (tous les jeux)',
    desc: 'Réduit la latence d’affichage dans certains jeux.',
    do: [R(GCS, 'GameDVR_FSEBehaviorMode', 2), R(GCS, 'GameDVR_HonorUserFSEBehaviorMode', 1), R(GCS, 'GameDVR_FSEBehavior', 2), R(GCS, 'GameDVR_DXGIHonorFSEWindowsCompatible', 1)],
    undo: [R(GCS, 'GameDVR_FSEBehaviorMode', 0), R(GCS, 'GameDVR_HonorUserFSEBehaviorMode', 0), R(GCS, 'GameDVR_FSEBehavior', 0), R(GCS, 'GameDVR_DXGIHonorFSEWindowsCompatible', 0)] },
  { id: 'mouse', cat: 'Jeux', rec: true, label: 'Désactiver l’accélération de la souris',
    desc: 'Visée plus précise : le curseur suit exactement ta main. Actif après reconnexion.',
    do: [RS(MOU, 'MouseSpeed', 0), RS(MOU, 'MouseThreshold1', 0), RS(MOU, 'MouseThreshold2', 0)],
    undo: [RS(MOU, 'MouseSpeed', 1), RS(MOU, 'MouseThreshold1', 6), RS(MOU, 'MouseThreshold2', 10)] },
  { id: 'sticky', cat: 'Jeux', rec: true, label: 'Désactiver les touches rémanentes',
    desc: 'Plus de fenêtre qui s’ouvre quand tu appuies 5 fois sur Maj en jeu.',
    do: [RS(ACCS + '\\StickyKeys', 'Flags', 506), RS(ACCS + '\\ToggleKeys', 'Flags', 58), RS(ACCS + '\\Keyboard Response', 'Flags', 122)],
    undo: [RS(ACCS + '\\StickyKeys', 'Flags', 510), RS(ACCS + '\\ToggleKeys', 'Flags', 62), RS(ACCS + '\\Keyboard Response', 'Flags', 126)] },
  // ---- Réseau ----
  { id: 'netthr', cat: 'Réseau', admin: true, label: 'Supprimer la limitation réseau multimédia',
    desc: 'Windows bride le réseau pendant la lecture multimédia : on retire cette limite.',
    do: [R(MM, 'NetworkThrottlingIndex', 4294967295)], undo: [R(MM, 'NetworkThrottlingIndex', 10)] },
  { id: 'dopt', cat: 'Réseau', admin: true, label: 'Ne plus partager ta bande passante pour les mises à jour',
    desc: 'Windows n’envoie plus de mises à jour à d’autres PC avec ta connexion.',
    do: [R('HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\DeliveryOptimization\\Config', 'DODownloadMode', 0)],
    undo: [R('HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\DeliveryOptimization\\Config', 'DODownloadMode', 1)] },
  // ---- Confidentialité et fond ----
  { id: 'tips', cat: 'Confidentialité', rec: true, label: 'Couper les publicités et suggestions de Windows',
    desc: 'Plus d’applications suggérées ni de pubs dans le menu Démarrer.',
    do: CDM_KEYS.map((k) => R(CDM, k, 0)), undo: CDM_KEYS.map((k) => R(CDM, k, 1)) },
  { id: 'bg', cat: 'Confidentialité', rec: true, label: 'Empêcher les applications de tourner en arrière-plan',
    desc: 'Libère de la mémoire et du processeur.',
    do: [R(BGA, 'GlobalUserDisabled', 1)], undo: [R(BGA, 'GlobalUserDisabled', 0)] },
  { id: 'adid', cat: 'Confidentialité', rec: true, label: 'Désactiver l’identifiant publicitaire',
    desc: 'Les applications ne peuvent plus te suivre pour la publicité.',
    do: [R('HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\AdvertisingInfo', 'Enabled', 0)],
    undo: [R('HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\AdvertisingInfo', 'Enabled', 1)] },
  { id: 'telem', cat: 'Confidentialité', admin: true, label: 'Réduire la collecte de données de Windows',
    desc: 'Limite les données de diagnostic envoyées à Microsoft.',
    do: [R('HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection', 'AllowTelemetry', 0)],
    undo: [RD('HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection', 'AllowTelemetry')] },
  { id: 'websrch', cat: 'Confidentialité', label: 'Retirer la recherche web du menu Démarrer',
    desc: 'La recherche ne lance plus Bing : plus rapide et moins de processus.',
    do: [R('HKCU\\Software\\Policies\\Microsoft\\Windows\\Explorer', 'DisableSearchBoxSuggestions', 1)],
    undo: [RD('HKCU\\Software\\Policies\\Microsoft\\Windows\\Explorer', 'DisableSearchBoxSuggestions')] },
  { id: 'widgets', cat: 'Confidentialité', admin: true, label: 'Désactiver les Widgets de Windows 11',
    desc: 'Arrête le panneau actualités et météo qui consomme de la mémoire.',
    do: [R('HKLM\\SOFTWARE\\Policies\\Microsoft\\Dsh', 'AllowNewsAndInterests', 0)],
    undo: [RD('HKLM\\SOFTWARE\\Policies\\Microsoft\\Dsh', 'AllowNewsAndInterests')] },
  // ---- Interface ----
  { id: 'fx', cat: 'Interface', rec: true, label: 'Désactiver les effets de transparence',
    desc: 'Allège l’affichage de Windows, surtout sur les petits PC.',
    do: [R(PERS, 'EnableTransparency', 0)], undo: [R(PERS, 'EnableTransparency', 1)] },
  { id: 'anim', cat: 'Interface', reboot: true, label: 'Réduire les animations de Windows',
    desc: 'Fenêtres et barre des tâches plus réactives. Actif après reconnexion.',
    do: [R(EXP + '\\VisualEffects', 'VisualFXSetting', 2), RS(DESK + '\\WindowMetrics', 'MinAnimate', 0), R(EXP + '\\Advanced', 'TaskbarAnimations', 0)],
    undo: [R(EXP + '\\VisualEffects', 'VisualFXSetting', 0), RS(DESK + '\\WindowMetrics', 'MinAnimate', 1), R(EXP + '\\Advanced', 'TaskbarAnimations', 1)] },
  { id: 'menu', cat: 'Interface', label: 'Menus sans délai',
    desc: 'Les menus s’affichent instantanément.',
    do: [RS(DESK, 'MenuShowDelay', 0)], undo: [RS(DESK, 'MenuShowDelay', 400)] },
  { id: 'sdelay', cat: 'Interface', rec: true, label: 'Supprimer le délai de lancement des programmes de démarrage',
    desc: 'Les programmes qui démarrent avec Windows se lancent tout de suite.',
    do: [R(EXP + '\\Serialize', 'StartupDelayInMSec', 0)], undo: [RD(EXP + '\\Serialize', 'StartupDelayInMSec')] },
  // ---- Disque et services ----
  { id: 'hiber', cat: 'Disque et services', admin: true, label: 'Désactiver l’hibernation',
    desc: 'Libère plusieurs Go sur le disque. Désactive aussi le démarrage rapide.',
    do: ['powercfg /hibernate off'], undo: ['powercfg /hibernate on'] },
  { id: 'svc', cat: 'Disque et services', admin: true, label: 'Arrêter deux services rarement utiles',
    desc: 'Cartes hors-ligne et mode démo magasin. Aucun impact sur l’usage courant.',
    do: ['sc config MapsBroker start= disabled', 'sc config RetailDemo start= disabled'],
    undo: ['sc config MapsBroker start= delayed-auto', 'sc config RetailDemo start= demand'] },
  // ---- Ajouts 2.2 ----
  { id: 'pthrot', cat: 'Performance', rec: true, admin: true, label: 'Désactiver la limitation de puissance des applications',
    desc: 'Windows bride certains programmes pour économiser l’énergie : on retire cette limite, surtout utile pour les jeux.',
    do: [R('HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\PowerThrottling', 'PowerThrottlingOff', 1)],
    undo: [RD('HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\PowerThrottling', 'PowerThrottlingOff')] },
  { id: 'timer', cat: 'Performance', admin: true, reboot: true, label: 'Horloge système haute précision',
    desc: 'Chaque programme garde sa propre précision d’horloge (Windows 11). Peut réduire les micro-saccades. Effet variable.',
    do: [R('HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\kernel', 'GlobalTimerResolutionRequests', 1)],
    undo: [RD('HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\kernel', 'GlobalTimerResolutionRequests')] },
  { id: 'usbsusp', cat: 'Performance', label: 'Ne jamais mettre les ports USB en veille (sur secteur)',
    desc: 'Évite qu’une souris ou un clavier USB se réveille avec un délai. Sans effet sur la batterie.',
    do: ['powercfg -setacvalueindex SCHEME_CURRENT 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 0', ACT],
    undo: ['powercfg -setacvalueindex SCHEME_CURRENT 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 1', ACT] },
  { id: 'pcie', cat: 'Performance', label: 'Carte graphique toujours à pleine liaison (PCIe, sur secteur)',
    desc: 'Désactive l’économie d’énergie du port de la carte graphique. Sans effet sur la batterie.',
    do: ['powercfg -setacvalueindex SCHEME_CURRENT 501a4d13-42af-4429-9fd1-a8218c268e20 ee12f906-d277-404b-b6da-e5fa1a576df5 0', ACT],
    undo: ['powercfg -setacvalueindex SCHEME_CURRENT 501a4d13-42af-4429-9fd1-a8218c268e20 ee12f906-d277-404b-b6da-e5fa1a576df5 1', ACT] },
  { id: 'wgames', cat: 'Jeux', rec: true, label: 'Optimisations pour les jeux en fenêtré',
    desc: 'Réduit la latence des jeux en « fenêtré sans bordure » (Windows 11). Sans effet en plein écran exclusif.',
    do: [RS('HKCU\\Software\\Microsoft\\DirectX\\UserGpuPreferences', 'DirectXUserGlobalSettings', '"SwapEffectUpgradeEnable=1;"')],
    undo: [RD('HKCU\\Software\\Microsoft\\DirectX\\UserGpuPreferences', 'DirectXUserGlobalSettings')] },
  { id: 'nagle', cat: 'Réseau', admin: true, label: 'Réduire la latence réseau (algorithme de Nagle)',
    desc: 'Envoie les petits paquets tout de suite : peut baisser le ping dans les jeux en ligne. Effet léger.',
    do: [String.raw`PS:$ErrorActionPreference='Stop'; Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces' | ForEach-Object { Set-ItemProperty -Path $_.PSPath -Name TcpAckFrequency -Value 1 -Type DWord; Set-ItemProperty -Path $_.PSPath -Name TCPNoDelay -Value 1 -Type DWord }`],
    undo: [String.raw`PS:Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces' | ForEach-Object { Remove-ItemProperty -Path $_.PSPath -Name TcpAckFrequency,TCPNoDelay -ErrorAction SilentlyContinue }`] },
  { id: 'qos', cat: 'Réseau', admin: true, label: 'Libérer la bande passante réservée par Windows (QoS)',
    desc: 'Supprime la réserve de débit gardée pour certains services système.',
    do: [R('HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Psched', 'NonBestEffortLimit', 0)],
    undo: [RD('HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Psched', 'NonBestEffortLimit')] },
  { id: 'dnsfast', cat: 'Réseau', admin: true, label: 'DNS rapide (Cloudflare 1.1.1.1)',
    desc: 'Sites et lanceurs de jeux trouvent leurs serveurs plus vite. N’agit pas sur le ping en jeu. Réversible.',
    do: [String.raw`PS:$ErrorActionPreference='Stop'; Get-NetAdapter | Where-Object Status -eq 'Up' | ForEach-Object { Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ServerAddresses ('1.1.1.1','1.0.0.1') }`],
    undo: [String.raw`PS:Get-NetAdapter | Where-Object Status -eq 'Up' | ForEach-Object { Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ResetServerAddresses }`] },
  { id: 'sysmain', cat: 'Disque et services', admin: true, label: 'Arrêter SysMain (Superfetch)',
    desc: 'Moins d’activité disque en arrière-plan si le jeu est sur un SSD. À éviter avec un disque dur classique.',
    do: ['sc config SysMain start= disabled', 'sc stop SysMain & exit /b 0'], undo: ['sc config SysMain start= auto', 'sc start SysMain & exit /b 0'] },
  { id: 'wsearch', cat: 'Disque et services', admin: true, label: 'Arrêter l’indexation de Windows Search',
    desc: 'Libère du disque et du processeur. La recherche de fichiers devient plus lente.',
    do: ['sc config WSearch start= disabled', 'sc stop WSearch & exit /b 0'], undo: ['sc config WSearch start= delayed-auto', 'sc start WSearch & exit /b 0'] },
];

async function runTweak(t, undo) {
  let ok = true;
  for (const c of undo ? t.undo : t.do) ok = (await (c.startsWith('PS:') ? ps(c.slice(3)) : run(c))).ok && ok;
  if (!undo && t.id === 'power' && !ok) {
    const r = await run('powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61');
    const g = (r.out.match(/[0-9a-f-]{36}/i) || [])[0];
    if (g) ok = (await run('powercfg /setactive ' + g)).ok;
  }
  return ok;
}
const mark = (id, on) => {
  const a = new Set(settings.applied || []);
  on ? a.add(id) : a.delete(id);
  settings.applied = [...a];
  save();
};

ipcMain.handle('boost:list', () =>
  TWEAKS.map(({ id, cat, label, desc, rec, admin, reboot }) => ({
    id, cat, label, desc, rec: !!rec, admin: !!admin, reboot: !!reboot, on: (settings.applied || []).includes(id),
  }))
);

ipcMain.handle(
  'boost:apply',
  guard(async (_, ids) => {
    const out = [];
    for (const t of TWEAKS.filter((t) => ids.includes(t.id))) {
      const ok = await runTweak(t, false);
      if (ok) mark(t.id, true);
      out.push({ id: t.id, ok });
    }
    return out;
  })
);

ipcMain.handle(
  'boost:revert',
  guard(async (_, ids) => {
    const out = [];
    for (const t of TWEAKS.filter((t) => !ids || ids.includes(t.id))) {
      const ok = await runTweak(t, true);
      if (ok) mark(t.id, false);
      out.push({ id: t.id, ok });
    }
    return out;
  })
);

const epicWeb = (l) => {
  try {
    const d = path.join(l, 'EpicGamesLauncher', 'Saved');
    return fs.readdirSync(d).filter((n) => /^webcache/i.test(n)).map((n) => path.join(d, n));
  } catch {
    return [];
  }
};

// ================= Nettoyage (jamais tes documents) =================
const CLEAN = () => {
  const l = process.env.LOCALAPPDATA || '';
  const w = process.env.SystemRoot || 'C:\\Windows';
  return [
    { id: 'temp', label: 'Fichiers temporaires de l’utilisateur', paths: [os.tmpdir()] },
    { id: 'wtemp', label: 'Fichiers temporaires de Windows', paths: [path.join(w, 'Temp')] },
    { id: 'dumps', label: 'Rapports de plantage', paths: [path.join(l, 'CrashDumps'), path.join(l, 'Microsoft', 'Windows', 'WER')] },
    {
      id: 'browser',
      label: 'Caches de Chrome et Edge (mots de passe et historique conservés)',
      paths: [
        path.join(l, 'Google', 'Chrome', 'User Data', 'Default', 'Cache', 'Cache_Data'),
        path.join(l, 'Microsoft', 'Edge', 'User Data', 'Default', 'Cache', 'Cache_Data'),
      ],
    },
    { id: 'launchers', label: 'Caches des lanceurs (Steam, Epic Games)', paths: [path.join(l, 'Steam', 'htmlcache'), ...epicWeb(l)] },
    {
      id: 'shader',
      label: 'Caches de shaders (peut causer des saccades au prochain lancement des jeux)',
      off: true,
      paths: [path.join(l, 'D3DSCache'), path.join(l, 'NVIDIA', 'DXCache'), path.join(l, 'NVIDIA', 'GLCache'), path.join(l, 'AMD', 'DxCache')],
    },
  ];
};

async function size(p) {
  let t = 0;
  let ents;
  try {
    ents = await fs.promises.readdir(p, { withFileTypes: true });
  } catch {
    return 0;
  }
  for (const e of ents) {
    const f = path.join(p, e.name);
    try {
      t += e.isDirectory() ? await size(f) : (await fs.promises.stat(f)).size;
    } catch {}
  }
  return t;
}

async function emptyDir(p) {
  let freed = 0;
  let ents;
  try {
    ents = await fs.promises.readdir(p, { withFileTypes: true });
  } catch {
    return 0;
  }
  for (const e of ents) {
    const f = path.join(p, e.name);
    try {
      const s = e.isDirectory() ? await size(f) : (await fs.promises.stat(f)).size;
      await fs.promises.rm(f, { recursive: true, force: true });
      if (!fs.existsSync(f)) freed += s;
    } catch {}
  }
  return freed;
}

ipcMain.handle('clean:scan', async () => {
  const out = [];
  for (const t of CLEAN()) {
    let s = 0;
    for (const p of t.paths) s += await size(p);
    out.push({ id: t.id, label: t.label, size: s, off: !!t.off });
  }
  return out;
});

ipcMain.handle(
  'clean:run',
  guard(async (_, ids) => {
    let freed = 0;
    for (const t of CLEAN().filter((t) => ids.includes(t.id))) for (const p of t.paths) freed += await emptyDir(p);
    return freed;
  })
);

// ================= Téléchargements automatiques =================
async function sweepDownloads() {
  if (!settings.dlEnabled || !status().ok) return;
  const dir = app.getPath('downloads');
  const cutoff = Date.now() - settings.dlMinutes * 60000;
  let ents;
  try {
    ents = await fs.promises.readdir(dir, { withFileTypes: true });
  } catch {
    return;
  }
  for (const e of ents) {
    if (/\.(crdownload|part|partial|tmp|download|opdownload)$/i.test(e.name)) continue;
    const f = path.join(dir, e.name);
    try {
      const s = await fs.promises.stat(f);
      if (Math.max(s.mtimeMs, s.birthtimeMs) > cutoff) continue;
      if (settings.dlPermanent) await fs.promises.rm(f, { recursive: true, force: true });
      else await shell.trashItem(f);
    } catch {}
  }
}

ipcMain.handle('dl:get', () => pubSettings());
ipcMain.handle('dl:set', (_, s) => {
  settings = {
    ...settings,
    dlEnabled: !!s.dlEnabled,
    dlMinutes: Math.max(5, Math.min(525600, Math.floor(+s.dlMinutes) || 60)),
    dlPermanent: !!s.dlPermanent,
  };
  save();
  return pubSettings();
});

// ================= Applications Windows inutiles =================
const BLOAT = [
  ['Microsoft.BingNews', 'Actualités'],
  ['Microsoft.BingWeather', 'Météo'],
  ['Microsoft.GetHelp', 'Obtenir de l’aide'],
  ['Microsoft.Getstarted', 'Astuces'],
  ['Microsoft.MicrosoftSolitaireCollection', 'Solitaire Collection'],
  ['Microsoft.ZuneMusic', 'Groove Musique / Lecteur multimédia'],
  ['Microsoft.ZuneVideo', 'Films et TV'],
  ['Microsoft.YourPhone', 'Mobile connecté'],
  ['Microsoft.WindowsFeedbackHub', 'Hub de commentaires'],
  ['Microsoft.MicrosoftOfficeHub', 'Office (publicités)'],
  ['Microsoft.People', 'Contacts'],
  ['Microsoft.SkypeApp', 'Skype'],
  ['MicrosoftTeams', 'Teams (version perso)'],
  ['Clipchamp.Clipchamp', 'Clipchamp'],
  ['Microsoft.WindowsMaps', 'Cartes'],
  ['Microsoft.MixedReality.Portal', 'Réalité mixte'],
  ['Microsoft.Microsoft3DViewer', 'Visionneuse 3D'],
  ['Microsoft.549981C3F5F10', 'Cortana'],
  ['king.com.CandyCrushSaga', 'Candy Crush Saga'],
  ['king.com.CandyCrushSodaSaga', 'Candy Crush Soda Saga'],
];

ipcMain.handle('debloat:list', async () => {
  const have = (await ps('Get-AppxPackage | Select-Object -ExpandProperty Name')).out.split(/\r?\n/).map((s) => s.trim());
  return BLOAT.filter((b) => have.includes(b[0])).map(([id, label]) => ({ id, label }));
});

ipcMain.handle(
  'debloat:run',
  guard(async (_, ids) => {
    await ps("Checkpoint-Computer -Description 'NovaBoost' -RestorePointType MODIFY_SETTINGS -ErrorAction SilentlyContinue");
    let n = 0;
    for (const [id] of BLOAT.filter((b) => ids.includes(b[0]))) {
      if ((await ps(`Get-AppxPackage -Name '${id}' | Remove-AppxPackage -ErrorAction Stop`)).ok) n++;
    }
    return n;
  })
);

// ================= Jeux : analyse + optimisation (sans toucher aux fichiers du jeu) =================
let GAMES = [];
const skipExe = /unins|crash|redist|setup|eac|easyanticheat|benchmark|launcher|helper|report/i;
function bigExe(dir, depth = 0) {
  let best = null;
  let bs = 0;
  let ents;
  try {
    ents = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return null;
  }
  for (const e of ents) {
    const f = path.join(dir, e.name);
    try {
      if (e.isDirectory()) {
        if (depth < 3 && !/redist|thirdparty|crash/i.test(e.name)) {
          const r = bigExe(f, depth + 1);
          if (r && r.s > bs) {
            best = r.f;
            bs = r.s;
          }
        }
      } else if (/\.exe$/i.test(e.name) && !skipExe.test(e.name)) {
        const s = fs.statSync(f).size;
        if (s > bs) {
          best = f;
          bs = s;
        }
      }
    } catch {}
  }
  return best ? { f: best, s: bs } : null;
}

async function scanGamesLib() {
  const out = [];
  const roots = ['C:\\Program Files (x86)\\Steam', 'C:\\Program Files\\Steam'].filter(fs.existsSync);
  const libs = new Set(roots);
  for (const s of roots) {
    try {
      const t = fs.readFileSync(path.join(s, 'steamapps', 'libraryfolders.vdf'), 'utf8');
      for (const m of t.matchAll(/"path"\s+"(.+?)"/g)) libs.add(m[1].replace(/\\\\/g, '\\'));
    } catch {}
  }
  for (const lib of libs) {
    const sa = path.join(lib, 'steamapps');
    let files = [];
    try {
      files = fs.readdirSync(sa).filter((f) => /^appmanifest_\d+\.acf$/.test(f));
    } catch {}
    for (const f of files) {
      try {
        const t = fs.readFileSync(path.join(sa, f), 'utf8');
        const name = (t.match(/"name"\s+"(.+?)"/) || [])[1];
        const dir = (t.match(/"installdir"\s+"(.+?)"/) || [])[1];
        if (!name || !dir || /steamworks|redistributable|proton|runtime/i.test(name)) continue;
        const r = bigExe(path.join(sa, 'common', dir));
        if (r) out.push({ name, store: 'Steam', exe: r.f, root: path.join(sa, 'common', dir) });
      } catch {}
    }
  }
  const ep = 'C:\\ProgramData\\Epic\\EpicGamesLauncher\\Data\\Manifests';
  try {
    for (const f of fs.readdirSync(ep).filter((f) => f.endsWith('.item'))) {
      try {
        const j = JSON.parse(fs.readFileSync(path.join(ep, f), 'utf8'));
        if (!j.DisplayName || !j.LaunchExecutable) continue;
        const exe = path.join(j.InstallLocation, j.LaunchExecutable);
        if (fs.existsSync(exe)) out.push({ name: j.DisplayName, store: 'Epic Games', exe, root: j.InstallLocation });
      } catch {}
    }
  } catch {}
  GAMES = out.sort((a, b) => a.name.localeCompare(b.name));
  return GAMES.map((g, id) => ({ id, name: g.name, store: g.store }));
}
ipcMain.handle('game:scan', () => scanGamesLib());

// Réglages Windows par jeu (ceux de « Paramètres > Graphismes ») : GPU performance + plein écran optimisé désactivé
ipcMain.handle(
  'game:boost',
  guard(async (_, id, undo) => {
    const g = GAMES[id];
    if (!g) return { gpu: false, fso: false };
    const GP = 'HKCU\\Software\\Microsoft\\DirectX\\UserGpuPreferences';
    const AC = 'HKCU\\Software\\Microsoft\\Windows NT\\CurrentVersion\\AppCompatFlags\\Layers';
    const a = undo
      ? `reg delete "${GP}" /v "${g.exe}" /f`
      : `reg add "${GP}" /v "${g.exe}" /t REG_SZ /d "GpuPreference=2;" /f`;
    const b = undo
      ? `reg delete "${AC}" /v "${g.exe}" /f`
      : `reg add "${AC}" /v "${g.exe}" /t REG_SZ /d "~ DISABLEDXMAXIMIZEDWINDOWEDMODE" /f`;
    return { gpu: (await run(a)).ok, fso: (await run(b)).ok };
  })
);

// Fortnite : modifie uniquement TON fichier de réglages (jamais le jeu), avec sauvegarde
ipcMain.handle(
  'game:fn',
  guard(async (_, fps, undo) => {
    const f = path.join(process.env.LOCALAPPDATA || '', 'FortniteGame', 'Saved', 'Config', 'WindowsClient', 'GameUserSettings.ini');
    if (!fs.existsSync(f)) return { ok: false, msg: 'Réglages Fortnite introuvables. Lance le jeu une fois.' };
    const bak = f + '.novaboost.bak';
    try {
      if (undo) {
        if (!fs.existsSync(bak)) return { ok: false, msg: 'Aucune sauvegarde à restaurer.' };
        fs.copyFileSync(bak, f);
        return { ok: true, msg: 'Réglages Fortnite d’origine restaurés.' };
      }
      if (!fs.existsSync(bak)) fs.copyFileSync(f, bak);
      let t = fs.readFileSync(f, 'utf8');
      const set = (k, v) => (t = t.replace(new RegExp(`^${k}=.*$`, 'mi'), `${k}=${v}`));
      ['ViewDistance', 'Shadow', 'AntiAliasing', 'Effects', 'PostProcess', 'Foliage'].forEach((k) => set(`sg.${k}Quality`, 0));
      set('FrameRateLimit', Number(fps || 144).toFixed(6));
      fs.writeFileSync(f, t);
      return { ok: true, msg: 'Profil FPS appliqué. Ferme Fortnite avant, puis relance-le.' };
    } catch {
      return { ok: false, msg: 'Impossible d’écrire le fichier (ferme Fortnite et réessaie).' };
    }
  })
);

// Nettoyage d'un jeu : uniquement journaux et rapports de plantage (jamais les fichiers du jeu)
ipcMain.handle(
  'game:clean',
  guard(async (_, id) => {
    const g = GAMES[id];
    if (!g || !g.root) return 0;
    let freed = 0;
    const walk = async (d, depth) => {
      let ents;
      try {
        ents = await fs.promises.readdir(d, { withFileTypes: true });
      } catch {
        return;
      }
      for (const e of ents) {
        const f = path.join(d, e.name);
        try {
          if (e.isDirectory()) {
            if (depth < 5) await walk(f, depth + 1);
          } else if (/\.(log|dmp|mdmp)$/i.test(e.name)) {
            const s = (await fs.promises.stat(f)).size;
            await fs.promises.rm(f, { force: true });
            freed += s;
          }
        } catch {}
      }
    };
    await walk(g.root, 0);
    if (/fortnite/i.test(g.name)) {
      const l = process.env.LOCALAPPDATA || '';
      for (const p of [path.join(l, 'FortniteGame', 'Saved', 'Logs'), path.join(l, 'FortniteGame', 'Saved', 'Crashes')]) freed += await emptyDir(p);
    }
    return freed;
  })
);

// ================= Moniteur en direct (type MSI Afterburner, lecture seule) =================
const MON_PS = `
$cpu=(Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor -Filter "Name='_Total'").PercentProcessorTime
$g=Get-CimInstance Win32_PerfFormattedData_GPUPerformanceCounters_GPUEngine -ErrorAction SilentlyContinue | Where-Object { $_.Name -like '*engtype_3D*' } | Measure-Object UtilizationPercentage -Sum
$m=Get-CimInstance Win32_PerfFormattedData_GPUPerformanceCounters_GPUAdapterMemory -ErrorAction SilentlyContinue | Measure-Object DedicatedUsage -Sum
$p=Get-CimInstance Win32_Processor | Select-Object -First 1
$t=$null
try { $z=Get-CimInstance -Namespace root/wmi -ClassName MSAcpi_ThermalZoneTemperature -ErrorAction Stop | Select-Object -First 1; $t=[math]::Round($z.CurrentTemperature/10-273.15,0) } catch {}
[pscustomobject]@{cpu=[int]$cpu;gpu=[math]::Min(100,[int]$g.Sum);vram=[double]$m.Sum;mhz=[int]$p.CurrentClockSpeed;max=[int]$p.MaxClockSpeed;temp=$t} | ConvertTo-Json -Compress
`;
let monBusy = false;
ipcMain.handle('mon:sample', async () => {
  if (monBusy) return null;
  monBusy = true;
  try {
    const o = JSON.parse((await ps(MON_PS)).out);
    o.ramTotal = os.totalmem();
    o.ramFree = os.freemem();
    return o;
  } catch {
    return null;
  } finally {
    monBusy = false;
  }
});

// ================= Programmes qui démarrent avec Windows (désactivation réversible) =================
const START_PS = String.raw`
$o=@()
foreach($h in 'HKCU:','HKLM:'){
  $run=$h+'\Software\Microsoft\Windows\CurrentVersion\Run'
  $ap=$h+'\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run'
  $p=Get-ItemProperty $run -ErrorAction SilentlyContinue
  if($p){ foreach($n in ($p.PSObject.Properties | Where-Object { $_.Name -notin @('PSPath','PSParentPath','PSChildName','PSDrive','PSProvider') })){
    $d=$false
    try { $b=(Get-ItemProperty $ap -ErrorAction Stop).($n.Name); if($b -and ($b[0] -band 1)){ $d=$true } } catch {}
    $o+=[pscustomobject]@{n=$n.Name;c=[string]$n.Value;s=$h.TrimEnd(':');d=$d}
  } }
}
ConvertTo-Json -InputObject @($o) -Compress
`;
let STARTUP = [];
ipcMain.handle('start:list', async () => {
  const r = await ps(START_PS);
  try {
    const j = JSON.parse(r.out || '[]');
    STARTUP = Array.isArray(j) ? j : [j];
  } catch {
    STARTUP = [];
  }
  return STARTUP;
});
ipcMain.handle(
  'start:set',
  guard(async (_, name, disable) => {
    if (!STARTUP.some((s) => s.n === name)) return false;
    const r = await ps(
      `$v=[byte[]](${disable ? 3 : 2},0,0,0,0,0,0,0,0,0,0,0); $ok=$false; foreach($h in 'HKCU:','HKLM:'){ try { $k=$h+'\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\Run'; if(-not (Test-Path $k)){ New-Item $k -Force | Out-Null }; Set-ItemProperty -Path $k -Name '${q(name)}' -Value $v -Type Binary -ErrorAction Stop; $ok=$true } catch {} }; if(-not $ok){ exit 1 }`
    );
    return r.ok;
  })
);

// ================= Touche pour masquer / afficher l'application =================
let tray = null;
function toggleWin() {
  if (!win) return;
  if (win.isVisible()) win.hide();
  else {
    win.show();
    win.focus();
  }
}
function applyHotkey() {
  globalShortcut.unregisterAll();
  if (!settings.hotkey) return;
  try {
    globalShortcut.register(settings.hotkey, toggleWin);
  } catch {}
}
function applyTray() {
  if (tray) {
    tray.destroy();
    tray = null;
  }
  if (settings.hideTray) return;
  try {
    tray = new Tray(nativeImage.createFromPath(path.join(__dirname, 'build', 'icon.png')).resize({ width: 16, height: 16 }));
    tray.setToolTip('NovaBoost');
    tray.setContextMenu(Menu.buildFromTemplate([{ label: 'Afficher / masquer', click: toggleWin }, { label: 'Quitter', click: () => app.quit() }]));
    tray.on('click', toggleWin);
  } catch {}
}
const okKey = (a) => {
  if (!/^((Ctrl|Alt|Shift)\+)*(F([1-9]|1[0-9]|2[0-4])|Insert|Delete|Home|End|PageUp|PageDown|Space|[A-Z0-9])$/.test(a)) return false;
  return a.includes('+') || /^(F\d+|Insert|Delete|Home|End|PageUp|PageDown)$/.test(a);
};
ipcMain.handle('set:hotkey', (_, acc) => {
  if (!acc) {
    settings.hotkey = '';
    settings.hideTray = false;
    save();
    applyHotkey();
    applyTray();
    return { ok: true };
  }
  if (!okKey(String(acc))) return { ok: false, msg: 'Touche refusée : utilise F1 à F24, ou Ctrl / Alt / Maj + une touche.' };
  globalShortcut.unregisterAll();
  let reg = false;
  try {
    reg = globalShortcut.register(acc, toggleWin);
  } catch {}
  if (!reg) {
    applyHotkey();
    return { ok: false, msg: 'Cette touche est déjà utilisée par un autre programme.' };
  }
  settings.hotkey = acc;
  save();
  return { ok: true };
});
ipcMain.handle('set:tray', (_, hide) => {
  if (hide && !settings.hotkey) return { ok: false, msg: 'Choisis d’abord une touche, sinon tu ne pourras plus rouvrir l’application.' };
  settings.hideTray = !!hide;
  save();
  applyTray();
  return { ok: true };
});

const pubSettings = () => {
  const { aiKey, ...o } = settings;
  return o;
};
// ================= Version 2.2 : programmes, navigateurs, réseau, conseiller, vérification des clés =================
const { safeStorage } = require('electron');
const safeJson = (s) => {
  try {
    return JSON.parse(s);
  } catch {
    return null;
  }
};
const toArr = (j) => (Array.isArray(j) ? j : j ? [j] : []);
const flag = (list, p, on) => {
  const k = p.toLowerCase();
  const s = new Set(settings[list] || []);
  on ? s.add(k) : s.delete(k);
  settings[list] = [...s];
  save();
};

// ---- Tous les programmes du PC (jeux, .exe, navigateurs) ----
let APPS = [];
const BROWSER_RX = /(^|\\)(chrome|msedge|firefox|brave|opera|opera_gx|vivaldi)\.exe$/i;
const GAME_RX = /steamapps|epic games|riot games|battle\.net|ubisoft|gog galaxy|gog games|ea games|electronic arts|rockstar|xbox games|\\games\\/i;
const SKIP_APP = /unins|uninstall|setup|crashpad|helper|\\windows\\|\\system32\\/i;
const kindOf = (p) => (BROWSER_RX.test(p) ? 'Navigateur' : GAME_RX.test(p) ? 'Jeu' : 'Programme');
const LNK_PS = String.raw`
$sh=New-Object -ComObject WScript.Shell
$d=@("$env:ProgramData\Microsoft\Windows\Start Menu\Programs","$env:APPDATA\Microsoft\Windows\Start Menu\Programs")
$o=foreach($f in (Get-ChildItem $d -Recurse -Filter *.lnk -ErrorAction SilentlyContinue)){ try{$t=$sh.CreateShortcut($f.FullName).TargetPath}catch{continue}; if($t -like '*.exe' -and (Test-Path -LiteralPath $t)){ [pscustomobject]@{n=$f.BaseName;p=$t} } }
ConvertTo-Json -InputObject @($o | Sort-Object p -Unique) -Compress
`;
async function scanApps() {
  if (!GAMES.length) await scanGamesLib();
  const found = [];
  const add = (name, p, k) => {
    if (p && fs.existsSync(p)) found.push({ name, path: p, kind: k || kindOf(p) });
  };
  for (const g of GAMES) add(g.name, g.exe, 'Jeu');
  for (const x of toArr(safeJson((await ps(LNK_PS)).out))) if (x && x.p && !SKIP_APP.test(x.p)) add(x.n, x.p);
  for (const p of settings.customApps || []) add(path.basename(p, '.exe'), p, kindOf(p) === 'Programme' ? 'Perso' : kindOf(p));
  const seen = new Set();
  APPS = found
    .filter((a) => {
      const k = a.path.toLowerCase();
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    })
    .sort((a, b) => a.name.localeCompare(b.name));
  return APPS;
}
const appsOut = () =>
  APPS.map((a, id) => ({
    id, name: a.name, kind: a.kind, path: a.path,
    boosted: (settings.boosted || []).includes(a.path.toLowerCase()),
    live: (settings.live || []).includes(a.path.toLowerCase()),
  }));
ipcMain.handle('app:scan', guard(async () => {
  await scanApps();
  return { apps: appsOut(), liveOn: !!settings.liveOn };
}));
ipcMain.handle('app:add', guard(async (_, p) => {
  if (!p) {
    const r = await dialog.showOpenDialog(win, { properties: ['openFile'], filters: [{ name: 'Programmes', extensions: ['exe'] }] });
    if (r.canceled) return { ok: false };
    p = r.filePaths[0];
  }
  p = String(p);
  if (!/\.exe$/i.test(p) || !fs.existsSync(p)) return { ok: false, msg: 'Choisis un fichier .exe.' };
  settings.customApps = [...new Set([...(settings.customApps || []), p])];
  save();
  await scanApps();
  return { ok: true, apps: appsOut() };
}));

// Réglages Windows par programme : carte graphique en « Performance » + plein écran optimisé désactivé
const GP_KEY = 'HKCU\\Software\\Microsoft\\DirectX\\UserGpuPreferences';
const AC_KEY = 'HKCU\\Software\\Microsoft\\Windows NT\\CurrentVersion\\AppCompatFlags\\Layers';
async function boostExe(exe, undo) {
  const a = undo ? `reg delete "${GP_KEY}" /v "${exe}" /f` : `reg add "${GP_KEY}" /v "${exe}" /t REG_SZ /d "GpuPreference=2;" /f`;
  const b = undo ? `reg delete "${AC_KEY}" /v "${exe}" /f` : `reg add "${AC_KEY}" /v "${exe}" /t REG_SZ /d "~ DISABLEDXMAXIMIZEDWINDOWEDMODE" /f`;
  return { gpu: (await run(a)).ok, fso: (await run(b)).ok };
}
ipcMain.handle('app:boost', guard(async (_, id, undo) => {
  const a = APPS[id];
  if (!a) return { gpu: false, fso: false };
  const r = await boostExe(a.path, undo);
  if (undo || (r.gpu && r.fso)) flag('boosted', a.path, !undo);
  return r;
}));
ipcMain.handle('app:live', guard((_, id, on) => {
  const a = APPS[id];
  if (!a) return false;
  flag('live', a.path, !!on);
  return true;
}));
ipcMain.handle('live:set', guard((_, on) => {
  settings.liveOn = !!on;
  save();
  return settings.liveOn;
}));

// Priorité « Haute » automatique pour les programmes choisis, dès qu'ils tournent
let liveBusy = false;
async function liveTick() {
  if (liveBusy || !settings.liveOn || !(settings.live || []).length || !status().ok) return;
  const names = [...new Set(settings.live.map((p) => path.basename(p, path.extname(p))).filter((n) => /^[\w .()-]+$/.test(n)))];
  if (!names.length) return;
  liveBusy = true;
  try {
    await ps(`Get-Process -Name ${names.map((n) => `'${q(n)}'`).join(',')} -ErrorAction SilentlyContinue | ForEach-Object { try { if ($_.PriorityClass -ne 'High') { $_.PriorityClass = 'High' } } catch {} }`);
  } finally {
    liveBusy = false;
  }
}

// Programmes ouverts qui consomment le plus de mémoire (on peut les fermer pour libérer le PC avant de jouer)
let TOP = [];
const PROTECT = /^(system|idle|registry|smss|csrss|wininit|winlogon|services|lsass|svchost|dwm|explorer|fontdrvhost|sihost|ctfmon|taskhostw|searchhost|startmenuexperiencehost|shellexperiencehost|audiodg|spoolsv|memcompression|novaboost|electron)$/i;
ipcMain.handle('proc:top', guard(async () => {
  const r = await ps(`Get-Process | Where-Object { $_.Id -ne ${process.pid} } | Sort-Object WorkingSet64 -Descending | Select-Object -First 40 Id,ProcessName,@{n='mb';e={[int]($_.WorkingSet64/1MB)}},@{n='win';e={[bool]$_.MainWindowTitle}} | ConvertTo-Json -Compress`);
  TOP = toArr(safeJson(r.out))
    .filter((p) => p && !PROTECT.test(p.ProcessName))
    .slice(0, 15)
    .map((p) => ({ id: p.Id, name: p.ProcessName, mb: p.mb, win: !!p.win }));
  return TOP;
}));
ipcMain.handle('proc:kill', guard(async (_, pid) => {
  const p = TOP.find((x) => x.id === pid);
  if (!p) return false;
  return (await ps(`Stop-Process -Id ${p.id} -Force -ErrorAction Stop`)).ok;
}));

// ---- Navigateurs : accélération matérielle, pas d'exécution en arrière-plan, carte graphique « Performance » ----
const BPOL = [
  ['HKCU\\Software\\Policies\\Google\\Chrome', [['HardwareAccelerationModeEnabled', 1], ['BackgroundModeEnabled', 0]]],
  ['HKCU\\Software\\Policies\\Microsoft\\Edge', [['HardwareAccelerationModeEnabled', 1], ['BackgroundModeEnabled', 0], ['StartupBoostEnabled', 0]]],
  ['HKCU\\Software\\Policies\\BraveSoftware\\Brave', [['HardwareAccelerationModeEnabled', 1], ['BackgroundModeEnabled', 0]]],
];
ipcMain.handle('browser:boost', guard(async (_, undo) => {
  if (!APPS.length) await scanApps();
  let n = 0;
  for (const [k, vals] of BPOL) for (const [v, d] of vals) if ((await run(undo ? RD(k, v) : R(k, v, d))).ok) n++;
  const br = APPS.filter((a) => a.kind === 'Navigateur');
  for (const a of br) {
    await boostExe(a.path, undo);
    flag('boosted', a.path, !undo);
  }
  return { browsers: br.map((a) => a.name), policies: n };
}));

// ---- Réseau : ping, gigue, perte de paquets, débit ----
async function pingHost(h) {
  const r = await run(`ping -n 8 -w 1500 ${h}`);
  const t = r.out
    .split(/\r?\n/)
    .filter((l) => /TTL/i.test(l))
    .map((l) => +((l.match(/(?:temps|time|zeit)\s*[=<]\s*(\d+)/i) || [])[1]))
    .filter((x) => isFinite(x));
  if (!t.length) return { host: h, loss: 100 };
  const avg = t.reduce((a, b) => a + b, 0) / t.length;
  const jit = t.length > 1 ? t.slice(1).reduce((a, x, i) => a + Math.abs(x - t[i]), 0) / (t.length - 1) : 0;
  return { host: h, min: Math.min(...t), avg: Math.round(avg), max: Math.max(...t), jitter: Math.round(jit), loss: Math.round((1 - t.length / 8) * 100) };
}
async function speedTest() {
  const o = {};
  try {
    const t0 = Date.now();
    const b = await (await fetch('https://speed.cloudflare.com/__down?bytes=25000000', { signal: AbortSignal.timeout(25000) })).arrayBuffer();
    o.down = +((b.byteLength * 8) / 1e6 / ((Date.now() - t0) / 1000)).toFixed(1);
  } catch {}
  try {
    const t0 = Date.now();
    await fetch('https://speed.cloudflare.com/__up', { method: 'POST', body: Buffer.alloc(5e6), signal: AbortSignal.timeout(25000) });
    o.up = +((5e6 * 8) / 1e6 / ((Date.now() - t0) / 1000)).toFixed(1);
  } catch {}
  return o;
}
ipcMain.handle('net:test', guard(async () => {
  const ping = [];
  for (const h of ['1.1.1.1', '8.8.8.8']) ping.push(await pingHost(h));
  return { ping, ...(await speedTest()), at: Date.now() };
}));
ipcMain.handle('net:flush', guard(async () => (await run('ipconfig /flushdns')).ok));

// ---- Conseiller IA (facultatif) : ta propre clé API Anthropic, gardée chiffrée sur ce PC ----
const AI_MODEL = 'claude-haiku-5-5';
const AI_SYS =
  'Tu es le conseiller de performance de l’application NovaBoost. Tu reçois des mesures d’un PC Windows (matériel, charge, réseau, réglages déjà appliqués). ' +
  'Réponds en français simple, en 6 conseils maximum, du plus utile au moins utile, chacun avec une action concrète que la personne peut faire elle-même ' +
  '(réglage dans un jeu, réglage Windows, geste matériel). Appuie-toi uniquement sur les mesures reçues, dis clairement quand une donnée manque, ' +
  'ne promets jamais un nombre de FPS précis. Ne conseille ni désactivation de la sécurité Windows, ni overclocking, ni outil douteux.';
const aiKey = () => {
  const v = settings.aiKey || '';
  try {
    if (v.startsWith('e:')) return safeStorage.decryptString(Buffer.from(v.slice(2), 'base64'));
    if (v.startsWith('p:')) return Buffer.from(v.slice(2), 'base64').toString();
  } catch {}
  return '';
};
ipcMain.handle('ai:has', () => !!aiKey());
ipcMain.handle('ai:setkey', guard((_, k) => {
  k = String(k || '').trim();
  if (!k) {
    settings.aiKey = '';
    save();
    return { ok: true, has: false };
  }
  if (!/^sk-ant-[\w-]{20,}$/.test(k)) return { ok: false, msg: 'Clé invalide : elle doit commencer par sk-ant-.' };
  settings.aiKey = safeStorage.isEncryptionAvailable() ? 'e:' + safeStorage.encryptString(k).toString('base64') : 'p:' + Buffer.from(k).toString('base64');
  save();
  return { ok: true, has: true };
}));
ipcMain.handle('ai:ask', guard(async (_, data, question) => {
  const key = aiKey();
  if (!key) return { ok: false, msg: 'Ajoute d’abord ta clé API.' };
  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({
        model: AI_MODEL,
        max_tokens: 1000,
        system: AI_SYS,
        messages: [{ role: 'user', content: `Mesures du PC (JSON) :\n${String(data).slice(0, 6000)}\n\nQuestion : ${String(question || 'Que dois-je faire pour avoir plus de FPS ?').slice(0, 500)}` }],
      }),
      signal: AbortSignal.timeout(45000),
    });
    const j = await r.json();
    if (!r.ok) return { ok: false, msg: r.status === 401 ? 'Clé API refusée.' : (j.error && j.error.message) || 'Erreur ' + r.status };
    return { ok: true, text: (j.content || []).map((c) => c.text || '').join('') };
  } catch {
    return { ok: false, msg: 'Connexion impossible.' };
  }
}));

// ---- Admin : vérifier que les clés fonctionnent vraiment ----
ipcMain.handle('adm:selftest', () => {
  if (!owner()) return { ok: false, msg: 'Réservé à l’administrateur.' };
  const out = { ok: true, priv: fs.existsSync(privFile()), pub: fs.existsSync(pubFile()) };
  try {
    const probe = crypto.randomBytes(16);
    out.match = crypto.verify(null, probe, fs.readFileSync(pubFile()), crypto.sign(null, probe, fs.readFileSync(privFile())));
    const P = { id: crypto.randomBytes(6).toString('hex'), n: 'test', d: 3600, c: Date.now(), m: '' };
    const data = Buffer.from(JSON.stringify(P));
    const sig = crypto.sign(null, data, fs.readFileSync(privFile())).toString('base64url');
    const good = parseKey('NB-' + data.toString('base64url') + '.' + sig);
    out.roundtrip = !!good && good.id === P.id;
    out.tamper = parseKey('NB-' + Buffer.from(JSON.stringify({ ...P, d: 99999999 })).toString('base64url') + '.' + sig) === null;
  } catch {
    out.match = false;
  }
  return out;
});
ipcMain.handle('adm:test', async (_, code) => {
  if (!owner()) return { ok: false, msg: 'Réservé à l’administrateur.' };
  const P = parseKey(code);
  if (!P) return { ok: false, msg: 'Code invalide : signature fausse, code coupé ou clé publique différente.' };
  const used = await run(`reg query "HKCU\\Software\\NovaBoost" /v u_${P.id}`);
  return { ok: true, name: P.n, reason: P.r, d: P.d, pc: P.m, created: P.c, usedHere: used.ok, thisPc: !P.m || P.m === machine };
});
ipcMain.handle('adm:backup', () => {
  if (!owner()) return { ok: false, msg: 'Réservé à l’administrateur.' };
  try {
    const dir = path.join(app.getPath('documents'), 'NovaBoost-sauvegarde-cle');
    fs.mkdirSync(dir, { recursive: true });
    const dest = path.join(dir, 'admin.key');
    fs.copyFileSync(privFile(), dest);
    shell.showItemInFolder(dest);
    return { ok: true, msg: 'Copie créée dans Documents\\NovaBoost-sauvegarde-cle. Mets-la sur une clé USB et ne la partage jamais.' };
  } catch {
    return { ok: false, msg: 'Sauvegarde impossible.' };
  }
});

// ================= Système, droits administrateur, fenêtre =================
ipcMain.handle('sys:info', async () => {
  const admin = (await run('net session')).ok;
  const gpu = (await ps('(Get-CimInstance Win32_VideoController | Select-Object -First 1 -ExpandProperty Name)')).out;
  const disk = (await ps('$d=Get-PSDrive C; "$($d.Free)|$($d.Used)"')).out.split('|').map(Number);
  const c = os.cpus();
  return {
    admin,
    gpu,
    cpu: c[0] ? c[0].model.trim() : 'Inconnu',
    cores: c.length,
    ramTotal: os.totalmem(),
    ramFree: os.freemem(),
    diskFree: disk[0],
    diskUsed: disk[1],
  };
});

ipcMain.handle('sys:elevate', async () => {
  const exe = q(process.execPath);
  const args = app.isPackaged ? '' : ` -ArgumentList '"${q(app.getAppPath())}"'`;
  const r = await ps(`Start-Process -FilePath '${exe}'${args} -Verb RunAs -ErrorAction Stop`);
  if (r.ok) setTimeout(() => app.quit(), 600);
  return r.ok;
});

ipcMain.handle('win:min', () => win && win.minimize());
ipcMain.handle('win:close', () => app.quit());

function createWindow() {
  win = new BrowserWindow({
    width: 1140,
    height: 740,
    minWidth: 960,
    minHeight: 640,
    frame: false,
    backgroundColor: '#07040f',
    icon: path.join(__dirname, 'build', 'icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false },
  });
  win.setMenuBarVisibility(false);
  win.webContents.on('will-navigate', (e) => e.preventDefault());
  win.loadFile('index.html');
}

app.setAppUserModelId('com.tonnom.novaboost');
app.whenReady().then(async () => {
  try {
    Object.assign(settings, JSON.parse(fs.readFileSync(sFile(), 'utf8')));
  } catch {}
  await initMachine();
  createWindow();
  applyHotkey();
  applyTray();
  setInterval(sweepDownloads, 60000);
  setInterval(liveTick, 10000);
});
app.on('window-all-closed', () => app.quit());
app.on('will-quit', () => globalShortcut.unregisterAll());
